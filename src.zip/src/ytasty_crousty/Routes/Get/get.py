from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional

# Supposez que vous avez configuré votre base de données et vos modèles/schémas ici :
# from database import get_db
# from models import RestaurantModel, ProductModel, OrderModel
# from schemas import RestaurantResponse, ProductResponse, OrderResponse

router = APIRouter(tags=["Gets (Lecture)"])


# 0. Santé de l'API
@router.get("/health", status_code=200)
def health_check():
    return {"status": "ok"}


# --- 3. RESTAURANTS ---

@router.get("/restaurants", response_model=List[RestaurantResponse])
def get_restaurants(db: Session = Depends(get_db)):
    restaurants = db.query(RestaurantModel).all()
    return restaurants


@router.get("/restaurants/{restaurant_id}", response_model=RestaurantResponse)
def get_restaurant_by_id(restaurant_id: int, db: Session = Depends(get_db)):
    restaurant = db.query(RestaurantModel).filter(RestaurantModel.id == restaurant_id).first()
    if not restaurant:
        raise HTTPException(status_code=404, detail="Restaurant non trouvé")
    return restaurant


# --- 4. PRODUITS / CARTE ---

@router.get("/products", response_model=List[ProductResponse])
def get_products(
        category: Optional[str] = Query(None),
        q: Optional[str] = Query(None, description="Filtre par mot-clé sur le nom ou la description"),
        restaurant_id: Optional[int] = Query(None),
        is_available: Optional[bool] = Query(None),
        db: Session = Depends(get_db)
):
    query = db.query(ProductModel)

    # Application des filtres obligatoires cumulables
    if category:
        query = query.filter(ProductModel.category == category)
    if q:
        query = query.filter(ProductModel.name.ilike(f"%{q}%"))
    if restaurant_id is not None:
        query = query.filter(ProductModel.restaurant_id == restaurant_id)
    if is_available is not None:
        query = query.filter(ProductModel.is_available == is_available)

    return query.all()


@router.get("/products/{product_id}", response_model=ProductResponse)
def get_product_by_id(product_id: int, db: Session = Depends(get_db)):
    product = db.query(ProductModel).filter(ProductModel.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Produit non trouvé")
    return product


# --- 5. COMMANDES ---

@router.get("/orders/{order_number}", response_model=OrderResponse)
def get_order_by_number(order_number: str, db: Session = Depends(get_db)):
    order = db.query(OrderModel).filter(OrderModel.order_number == order_number).first()
    if not order:
        raise HTTPException(status_code=404, detail="Commande non trouvée")
    return order


@router.get("/restaurants/{restaurant_id}/orders", response_model=List[OrderResponse])
def get_restaurant_orders(
        restaurant_id: int,
        status: Optional[str] = Query(None, description="Filtrer par statut (ex: pending, preparing)"),
        db: Session = Depends(db_dep)
        # Remplacez par votre dépendance d'authentification et de vérification des rôles/restaurant
):
    query = db.query(OrderModel).filter(OrderModel.restaurant_id == restaurant_id)
    if status:
        query = query.filter(OrderModel.status == status)
    return query.all()